#include "answer.h"

my_t
life_universe_and_everything() {
  return 42;
}
