#ifndef _NIFTY_TUTORIAL_TYPES_H
#define _NIFTY_TUTORIAL_TYPES_H

typedef short my_t;

#endif /* _NIFTY_TUTORIAL_ANSWER_H_ */
