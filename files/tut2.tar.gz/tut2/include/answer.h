#ifndef _NIFTY_TUTORIAL_ANSWER_H_
#define _NIFTY_TUTORIAL_ANSWER_H_

#include "types.h"

extern my_t life_universe_and_everything();

#endif /* _NIFTY_TUTORIAL_ANSWER_H_ */
