-module(answer).
-export([
	'life_universe_and_everything'/0,
	get_types/0,
	erlptr_to_record/1,
	record_to_erlptr/1,
	new/1
	]).

-compile(nowarn_unused_record).

-define(TYPES, {dict,2,16,16,8,80,48,
      {[],[],[],[],[],[],[],[],[],[],[],[],[],[],[],[]},
      {{[],[],[],[],
        [["my_t"|{typedef,"short"}]],
        [],[],
        [["short"|{base,["int","signed","short"]}]],
        [],[],[],[],[],[],[],[]}}}).

-on_load(init/0).

-type addr() :: integer().
-type typename() :: string.
-type ptr() :: {addr(), typename()}.

init() -> %% loading code from jiffy
    PrivDir = case code:priv_dir(?MODULE) of
        {error, _} ->
            EbinDir = filename:dirname(code:which(?MODULE)),
            AppPath = filename:dirname(EbinDir),
            filename:join(AppPath, "priv");
        Path ->
            Path
    end,
    erlang:load_nif(filename:join(PrivDir, "answer_nif"), 0).

'life_universe_and_everything'() ->
	erlang:nif_error(nif_library_not_loaded).


%%% static

-spec erlptr_to_record(ptr()) -> tuple().
erlptr_to_record(_) ->
    erlang:nif_error(nif_library_not_loaded).

-spec record_to_erlptr(tuple()) -> ptr().
record_to_erlptr(_) ->
    erlang:nif_error(nif_library_not_loaded).

-spec get_types() -> dict().
get_types() -> ?TYPES.

-spec new(typename()) -> term().
new(_) ->
    erlang:nif_error(nif_library_not_loaded).
