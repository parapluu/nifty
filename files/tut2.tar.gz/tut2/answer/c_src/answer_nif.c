#include <erl_nif.h>
#include <string.h>
#include <stdint.h>

#include <stdio.h>

#include "/home/thegeorge/projects/priv/nifty-tutorials/tut2/include/answer.h"

#if _WIN32 || _WIN64
	#if _WIN64
typedef unsigned __int64 uint64_t;
		#define ENV64BIT
	#else
typedef unsigned __int32 uint32_t;
		#define ENV32BIT
	#endif
#else // clang gcc
#include <stdint.h>
	#if __x86_64__
		#define ENV64BIT
	#else
		#define ENV32BIT
	#endif
#endif 

/*
 * forward declarations
 */







/*
 * Stucts
 */






static ERL_NIF_TERM
record_to_erlptr(ErlNifEnv* env, int argc, const ERL_NIF_TERM argv[])
{
	int err, written, tmp, ar;
	unsigned int l;
	char* cstr;
	ERL_NIF_TERM *tpl;
	
	err = enif_get_tuple(env, argv[0], &ar, (const ERL_NIF_TERM**)(&tpl));
	if (!err) {
		goto error;
	}

	err = enif_get_atom_length(env, tpl[0], &l, ERL_NIF_LATIN1);
	if (!err) {
		goto error;
	}

	l+=1;
	cstr = enif_alloc(sizeof(char)*l);
	written = 0;
	while (written<(l)) {
		tmp = enif_get_atom(env, tpl[0], cstr+written, l-written, ERL_NIF_LATIN1);
		if (tmp==-(l-written)) {
				tmp=-tmp;
		}
		if (tmp<=0) {
			enif_free(cstr);
			goto error;
		}
		written += tmp;
	}


error:
	return enif_make_badarg(env);
}

static ERL_NIF_TERM
erlptr_to_record(ErlNifEnv* env, int argc, const ERL_NIF_TERM argv[])
{
	int err, written, tmp;
	unsigned int l;
	uint64_t ptr;
	char* cstr;

	ERL_NIF_TERM *tpl;

	err = enif_get_tuple(env, argv[0], &tmp, (const ERL_NIF_TERM**)(&tpl));
	if (!err) {
		goto error;
	}

	err = enif_get_list_length(env, tpl[1], &l);
	if (!err) {
		goto error;
	}

	l+=1;
	cstr = enif_alloc(sizeof(char)*l);
	written = 0;
	while (written<(l)) {
		tmp = enif_get_string(env, tpl[1], cstr+written, l-written, ERL_NIF_LATIN1);
		if (tmp==-(l-written)) {
			tmp=-tmp;
		}
		if (tmp<=0) {
			enif_free(cstr);
			goto error;
		}
		written += tmp;
	}

	err = enif_get_uint64(env, tpl[0], &ptr);
	if (!err) {
		goto error;
	}





error:
	return enif_make_badarg(env);
}

static ERL_NIF_TERM
new_type_object(ErlNifEnv* env, int argc, const ERL_NIF_TERM argv[])
{
	int err, written, tmp;
	unsigned int l;
	char* cstr;
	uint64_t type_holder;
	ERL_NIF_TERM retval;

	err = enif_get_list_length(env, argv[0], &l);
	if (!err) {
		goto error;
	}

	l+=1;
	cstr = enif_alloc(sizeof(char)*l);
	written = 0;
	while (written<(l)) {
		tmp = enif_get_string(env, argv[0], cstr+written, l-written, ERL_NIF_LATIN1);
		if (tmp==-(l-written)) {
			tmp=-tmp;
		}
		if (tmp<=0) {
			enif_free(cstr);
			goto error;
		}
		written += tmp;
	}
/* structs */

	
		
			
			
		
	
		
			
			
		
	

error:
	return enif_make_badarg(env);
/* supress warnings */
	type_holder++;
	retval++;
}


/*
 * Build Function Definitions
 */


static ERL_NIF_TERM
erl2c_life_universe_and_everything(ErlNifEnv* env, int argc, const ERL_NIF_TERM argv[])
{
	int err=0;



	
		
			
			
				
					
						
							
								
	
		
			
	
	
	short c_retval;
	ERL_NIF_TERM retval;
	
	










		
	


							
						
					
				
			
		
	

	
		
			
		
	
	
	
		
			
				
					
						
	c_retval =
						
					
				
			
		
	
	
		
			
				
					
						
							
								
	
		
			





(short)







		
	


							
						
					
				
			
		
	
	life_universe_and_everything(
		
			
				
				
			
		
		);

	
		
			
				
					
						
							
								
	
		
			






	retval = 
	
	enif_make_int
	
	
	
	
	
	(env, c_retval);




		
	


							
						
					
				
			
		
	

	
		
			
		
	
	
	return retval;
error:
	return enif_make_badarg(env);
goto error;
	err++;
}




/*
 * Function definitions for ErLang
 */
static ErlNifFunc nif_funcs[] = {
	
	{"life_universe_and_everything", 0, erl2c_life_universe_and_everything},
	
	{"erlptr_to_record", 1, erlptr_to_record},
	{"record_to_erlptr", 1, record_to_erlptr},
	{"new", 1, new_type_object}
	};

int upgrade(ErlNifEnv* env, void** priv_data, void** old_priv_data, ERL_NIF_TERM load_info)
{
	return 0;
}

ERL_NIF_INIT(answer, nif_funcs, NULL, NULL, upgrade, NULL);
