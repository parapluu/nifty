extern int works();
extern void fails();

