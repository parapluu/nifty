#include "test.h"
#include "signal.h"

int
works()
{
  return 42;
}

void
fails()
{
  raise(SIGSEGV);
}
