extern int fib(int n);
